# Basic Translation Plugin
A plugin trying to make OSRS more inclusive to non-english speaking players. Currently this just takes some options I found while running around runescape right clicking and translates them to another language. This is done with a CSV instead of on the fly translating to prevent the need for an API Key or extra web traffic. Currently only a few languages are offered but I plan on adding more languages later. I removed the accents over letters because it causes rending issues sometimes. More right click options will be added as I remember to, if you would like to add some of your own or work on another language just make a pull request or issue and I will look into it when I have time. 

Current languages:  
Spanish  
German  
French  
Russian (Broken ATM)  

To add new languages copy the master.csv as a starter. To add new menu options append them to the bottom of master.csv
