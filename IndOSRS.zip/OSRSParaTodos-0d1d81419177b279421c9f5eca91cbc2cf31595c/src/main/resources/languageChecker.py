#TODO add language checker to allow for more easy maintenance of new or old languages.
